#!/usr/bin/php
<?php

	// Use a copy of the original argv:
	$args = $argv;

	// Remove the first argument (the script's path):
	array_shift($args);

	// Defines a new array to store the results
	$items = array();

	foreach($args as $arg) {
		
		$result = dns_get_record($arg);
		
		foreach ($result as $key => $val) {
			
			array_push(
			$items, 
			array(
				"title" => trim($val['ip'].$val['target']),
				"badge" => $val['type'],
				"alwaysShowsSubtitle" => true
			));
		}		
		
	}

	print json_encode($items);